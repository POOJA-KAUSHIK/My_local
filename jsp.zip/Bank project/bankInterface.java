import java.io.*;

public interface bankInterface{

public String getData(String Name,String Id,String Email,String Password);

}