/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



function validateform(){  
var name=document.myform.Name.value;  
var password=document.myform.Password.value;  
var mobileno=document.myform.Mobileno.value; 
var email=document.myform.Email.value; 


if (name==null || name==""){  
  alert("Name can't be blank");  
  return false;  
}
if(password.length<6){  
	  alert("Password must be at least 6 characters long.");  
  return false;  
  }
if (mobileno=="" || isNaN(mobileno)|| mobileno.length!=10){
  
	  alert("enter correct mobile no."); 
mobileno.focus();
return false; 
}
return (true);
}
 

