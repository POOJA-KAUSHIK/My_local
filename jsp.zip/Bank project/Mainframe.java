
import javax.swing.*;
import java.awt.*;
 import java.awt.event.*;

public class Mainframe extends JFrame  {
@EJB bean;

JLabel l1=new JLabel("Enter Email");
JTextField t1=new JTextField(40);

JLabel l2=new JLabel("Enter Password");
JTextField t2=new JTextField(30);

JButton b1=new JButton("LOGIN");
JButton b2=new JButton("Register");
 
public Mainframe(){
l1.setBounds(50,100,100,30);
l2.setBounds(50,170,100,30);

t1.setBounds(200,100,100,30);
t2.setBounds(200,170,100,30);

b1.setBounds(50,240,100,30);
b2.setBounds(50,310,200,40);


add(l1);   add(l2);  add(t1);  add(t2);  add(b1); add(b2);
setVisible(true);
setLayout(null);
setSize(800,800);

}

public static void main(String args[]){

new Mainframe();
bean.getData("pooja","e1","pk@gmail.com","pooja");
}
}