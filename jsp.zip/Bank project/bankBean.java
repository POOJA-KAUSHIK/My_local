import java.io.*;
import java.sql.*;

public class bankBean extends bankInterface{
public String getData(String Name,String Id,String Email,String Password)
{
String n=Name;String i=Id;
String e=Email;String p=Password;

try{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
Statement st=con.createStatement();
ResultSet rs=st.execute("insert into Banktable values('"+n+"','"+i+"','"+e+"','"+p+"')");
}
catch(Exception e){
System.out.println(e);
}

return n;
return i;
return e;
return p;
}

}