
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Register extends JFrame implements ActionListener {

@EJB bean;
JLabel l1=new JLabel("Enter Name");
JTextField t1=new JTextField(40);

JLabel l2=new JLabel("Enter id");
JTextField t2=new JTextField(40);

JLabel l3=new JLabel("Enter Email");
JTextField t3=new JTextField(40);

JLabel l4=new JLabel("Enter Password");
JTextField t4=new JTextField(40);

JButton b1=new JButton("Register");
 
public Register(){
l1.setBounds(50,100,100,30);
l2.setBounds(50,170,100,30);
l3.setBounds(50,240,100,30);
l4.setBounds(50,310,100,30);

t1.setBounds(300,100,200,30);
t2.setBounds(300,170,200,30);
t3.setBounds(300,240,200,30);
t4.setBounds(300,310,200,30);

b1.setBounds(50,400,100,30);
b2.setBounds(300,400,100,30);
b1.addActionListener(this);
b2.addActionListener(this);
add(l1);   add(l2);  add(l3); add(l4); 
add(t1);  add(t2);  add(t3);  add(t4); 
add(b1);  add(b2);
setVisible(true);
setLayout(null);
setSize(800,800);

}

public void actionPerformed(ActionEvent e){

t1.getText();   t2.getText();
t3.getText();   t4.getText();

if(e.getSource()==b1){
System.out.println("back");

}
if(e.getSource()==b2){
System.out.println("data entered");
bean.getData('"+n+"','"+i+"','"+e+"','"+p+"');
}
}
public static void main(String args[]){

new Register();

}
}