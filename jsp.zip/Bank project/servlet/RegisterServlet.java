import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.http.*;
public class RegisterServlet extends HttpServlet{

public void doPost(HttpServletRequest req,HttpServletResponse res)
throws ServletException,IOException{

res.setContentType("text/html");
PrintWriter pw=req.getWriter();

String Sname=request.getParameter("name");
String Sid=request.getParameter("id"); 
String Semail=request.getParameter("email");
String Spassword=request.getParameter("password");

try{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
Statement st=con.createStatement();

ResultSet rs=st.execute("insert into Banktable values('"+Sname+"','"+Sid+"','"+Semail+"','"+Spassword+"')");
}
catch(Exception e){
System.out.println(e);
}

}
}

}