import javax.servlet.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet{


public void doPost(HttpServletRequest req,HttpServletResponse res)
throws ServletException,IOException{

res.setContentType("text/html");
PrintWriter pw=req.getWriter();
 
String Semail=request.getParameter("email");
 
String Spassword=request.getParameter("password");

try{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
Statement st=con.createStatement();
//st.execute("create table mydb(name varchar(30))");

ResultSet rs=st.execute("select Email,Password from Banktable");

String dbemail;
String dbpass;
while(rs.next()){
 dbemail=rs.getString("Email");
 dbpass=rs.getString("Password");

if(dbemail.equals(Semail) && dbpass.equals(Spassword)){

RequestDispatcher r=request.getRequestDispatcher("/alreg.html");
r.forward(request,response);

}
else{
RequestDispatcher r=request.getRequestDispatcher("/Login.html");
r.forward(request,response);

}

}
catch(Exception e){
System.out.println(e);
}

}
}

}