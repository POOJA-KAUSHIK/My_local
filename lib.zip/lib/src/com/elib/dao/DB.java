package com.elib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
public class DB {

	public static Connection getCon(){
		Connection con=null;
		try{
Class.forName("oracle.jdbc.driver.OracleDriver");

 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system2", "12345");
		
		}catch(Exception e){System.out.println(e);}
		return con;
	}

     }
